<?php
include_once "guerrero.php";
include_once "arquero.php";
include_once "mago.php";

class PersonajeDatos{       //clase que utiliza herencia: Personnajes->(guerrero, mago y arquero)
    private $database; 

    public function __construct($database){
        $this->database = $database;
    }

    //Listado completo
    public function listarPersonajes(){
        $filas = $this->database->select("personajes", "*");
        $personajes = [];
        $armaDatos = new armaDatos($this->database);

        foreach($filas as $fila){
            //verifico si hay arma 
            $armaObj = null;
            if($fila["idArmaEquipada"] != null){
                $armaObj = $armaDatos->buscarArma($fila["idArmaEquipada"]);
            } 

            //Segun tipoPersonaje se crea el objeto Personaje(guerrero/mago/arquero)
            if($fila["tipoPersonaje"] == "guerrero"){

                $guerrero = new Guerrero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"], 
                    $fila["estado"], 
                    $armaObj,               //null u objeto
                    $fila["fuerza"],
                    $fila["armadura"]
                );

                $personajes[] = $guerrero;

            } elseif ($fila["tipoPersonaje"] == "mago"){
                $mago = new Mago(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,           //null u objeto
                    $fila["mana"],
                    $fila["inteligencia"]
                );
                $personajes[] = $mago;
            } else {
                $arquero = new Arquero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,               //null u objeto
                    $fila["precisionPersonaje"],
                    $fila["velocidad"]
                );
                $personajes[] = $arquero;
            }
        }

        return $personajes;
    }

    //Búsqueda por ID
    public function buscarPersonaje($id){
        $fila = $this->database->select("personajes", "*", ["id" => $id]);
        $resultado = null;
        
        //si hay fila
        if($fila != null){
            //verifico arma
            $armaDatos = new armaDatos($this->database);
            $armaObj = null;
            if($fila[0]["idArmaEquipada"] != null){
            $armaObj = $armaDatos->buscarArma($fila[0]["idArmaEquipada"]);
            }

            //creo Obj segun tipo Personaje
            if($fila[0]["tipoPersonaje"] == "guerrero"){
                $guerrero = new Guerrero(
                    $fila[0]["id"], 
                    $fila[0]["nombre"],
                    $fila[0]["nivel"],
                    $fila[0]["puntosVida"],
                    $fila[0]["energia"],
                    $fila[0]["duelosGanados"],
                    $fila[0]["duelosPerdidos"], 
                    $fila[0]["estado"], 
                    $armaObj,               //null u obj
                    $fila[0]["fuerza"],
                    $fila[0]["armadura"]
                );
                $resultado = $guerrero;    

            } elseif ($fila[0]["tipoPersonaje"] == "mago"){
                $mago = new Mago(
                    $fila[0]["id"], 
                    $fila[0]["nombre"],
                    $fila[0]["nivel"],
                    $fila[0]["puntosVida"],
                    $fila[0]["energia"],
                    $fila[0]["duelosGanados"],
                    $fila[0]["duelosPerdidos"], 
                    $fila[0]["estado"], 
                    $armaObj,               //null u obj
                    $fila[0]["mana"],
                    $fila[0]["inteligencia"]
                );
                $resultado = $mago;

            } else {
                $arquero = new Arquero(
                    $fila[0]["id"], 
                    $fila[0]["nombre"],
                    $fila[0]["nivel"],
                    $fila[0]["puntosVida"],
                    $fila[0]["energia"],
                    $fila[0]["duelosGanados"],
                    $fila[0]["duelosPerdidos"], 
                    $fila[0]["estado"], 
                    $armaObj,               //null u obj
                    $fila[0]["precisionPersonaje"],
                    $fila[0]["velocidad"]
                );
                $resultado = $arquero;

            }
        }
        return $resultado;
    }

//Insertar (alta)
public function insertarPersonaje(Personaje $personaje){
    //verifico arma equipada (obj o null)
    $idArma = null;
    if($personaje->getArmaEquipada() != null){
        $idArma = $personaje->getArmaEquipada()->getIdArma(); 
    }
    
    //inserto segun tipo personaje
    if($personaje instanceof Guerrero){

        $this->database->insert("personajes",[
            "nombre" => $personaje->getNombre(),
            "tipoPersonaje" => "guerrero",
            "nivel" => $personaje->getNivel(),
            "puntosVida" => $personaje->getPuntosVida(),
            "energia" => $personaje->getEnergia(),
            "duelosGanados" => $personaje->getDuelosGanados(),
            "duelosPerdidos" => $personaje->getDuelosPerdidos(),
            "estado" => $personaje->getEstado(),
            "idArmaEquipada" => $idArma,
            "fuerza" => $personaje->getFuerza(),
            "armadura" =>$personaje->getArmadura()
        ]);

    } elseif ($personaje instanceof Mago){

        $this->database->insert("personajes",[
            "nombre" => $personaje->getNombre(),
            "tipoPersonaje" => "mago",
            "nivel" => $personaje->getNivel(),
            "puntosVida" => $personaje->getPuntosVida(),
            "energia" => $personaje->getEnergia(),
            "duelosGanados" => $personaje->getDuelosGanados(),
            "duelosPerdidos" => $personaje->getDuelosPerdidos(),
            "estado" => $personaje->getEstado(),
            "idArmaEquipada" => $idArma,
            "mana" => $personaje->getMana(),
            "inteligencia" =>$personaje->getInteligencia()
        ]);

    } elseif ($personaje instanceof Arquero) {

        $this->database->insert("personajes",[
            "nombre" => $personaje->getNombre(),
            "tipoPersonaje" => "arquero",
            "nivel" => $personaje->getNivel(),
            "puntosVida" => $personaje->getPuntosVida(),
            "energia" => $personaje->getEnergia(),
            "duelosGanados" => $personaje->getDuelosGanados(),
            "duelosPerdidos" => $personaje->getDuelosPerdidos(),
            "estado" => $personaje->getEstado(),
            "idArmaEquipada" => $idArma,
            "precisionPersonaje" => $personaje->getPrecisionPersonaje(),
            "velocidad" =>$personaje->getVelocidad()
        ]);
    }
}

//modificacion
public function modificarPersonaje(Personaje $personaje){
    //verifico arma equipada (obj o null)
    $idArma = null;
    if($personaje->getArmaEquipada() != null){
        $idArma = $personaje->getArmaEquipada()->getIdArma(); 
    }

    //modifico segun tipo de personaje
    if ($personaje instanceof Guerrero){
        $this->database->update("personajes", 
        [
            "nombre" => $personaje->getNombre(),
            "tipoPersonaje" => "guerrero",
            "nivel" => $personaje->getNivel(),
            "puntosVida" => $personaje->getPuntosVida(),
            "energia" => $personaje->getEnergia(),
            "duelosGanados" => $personaje->getDuelosGanados(),
            "duelosPerdidos" => $personaje->getDuelosPerdidos(),
            "estado" => $personaje->getEstado(),
            "idArmaEquipada" => $idArma,
            "fuerza" => $personaje->getFuerza(),
            "armadura" =>$personaje->getArmadura()
        ], 

        ["id" => $personaje->getIdPersonaje()]);

    } elseif ($personaje instanceof Mago){
        $this->database->update("personajes", 
        [
            "nombre" => $personaje->getNombre(),
            "tipoPersonaje" => "mago",
            "nivel" => $personaje->getNivel(),
            "puntosVida" => $personaje->getPuntosVida(),
            "energia" => $personaje->getEnergia(),
            "duelosGanados" => $personaje->getDuelosGanados(),
            "duelosPerdidos" => $personaje->getDuelosPerdidos(),
            "estado" => $personaje->getEstado(),
            "idArmaEquipada" => $idArma,
            "mana" => $personaje->getMana(),
            "inteligencia" =>$personaje->getInteligencia()
        ], 
        
        ["id" => $personaje->getIdPersonaje()]);

    } elseif ($personaje instanceof Arquero){
        $this->database->update("personajes", 
        [
            "nombre" => $personaje->getNombre(),
            "tipoPersonaje" => "arquero",
            "nivel" => $personaje->getNivel(),
            "puntosVida" => $personaje->getPuntosVida(),
            "energia" => $personaje->getEnergia(),
            "duelosGanados" => $personaje->getDuelosGanados(),
            "duelosPerdidos" => $personaje->getDuelosPerdidos(),
            "estado" => $personaje->getEstado(),
            "idArmaEquipada" => $idArma,
            "precisionPersonaje" => $personaje->getPrecisionPersonaje(),
            "velocidad" =>$personaje->getVelocidad()
        ], 
        
        ["id" => $personaje->getIdPersonaje()]);
    }
}

//Eliminar (baja)
public function eliminarPersonaje($id){
    $this->database->delete("personajes", ["id" => $id]);
}

/*-----------------------------------------------------------------------------------------------------*/

//Listar personajes disponibles para duelar
public function personajesDisponibles(){
    $filas = $this->database->select("personajes", "*", ["estado" => "disponible"]); //WHERE

    //Reutilizo logica de listar personajes
    $personajes = [];
    $armaDatos = new armaDatos($this->database);

        foreach($filas as $fila){
            //verifico si hay arma 
            $armaObj = null;
            if($fila["idArmaEquipada"] != null){
                $armaObj = $armaDatos->buscarArma($fila["idArmaEquipada"]);
            } 

            //Segun tipoPersonaje se crea el objeto Personaje(guerrero/mago/arquero)
            if($fila["tipoPersonaje"] == "guerrero"){

                $guerrero = new Guerrero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"], 
                    $fila["estado"], 
                    $armaObj,               //null u objeto
                    $fila["fuerza"],
                    $fila["armadura"]
                );

                $personajes[] = $guerrero;

            } elseif ($fila["tipoPersonaje"] == "mago"){
                $mago = new Mago(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,           //null u objeto
                    $fila["mana"],
                    $fila["inteligencia"]
                );
                $personajes[] = $mago;
            } else {
                $arquero = new Arquero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,               //null u objeto
                    $fila["precisionPersonaje"],
                    $fila["velocidad"]
                );
                $personajes[] = $arquero;
            }
        }

        return $personajes;
}

//Listar personajes lesionados.
public function personajesLesionados(){
    $filas = $this->database->select("personajes", "*", ["estado" => "lesionado"]);

    //Reutilizo logica de listar personajes
    $personajes = [];
    $armaDatos = new armaDatos($this->database);

        foreach($filas as $fila){
            //verifico si hay arma 
            $armaObj = null;
            if($fila["idArmaEquipada"] != null){
                $armaObj = $armaDatos->buscarArma($fila["idArmaEquipada"]);
            } 

            //Segun tipoPersonaje se crea el objeto Personaje(guerrero/mago/arquero)
            if($fila["tipoPersonaje"] == "guerrero"){

                $guerrero = new Guerrero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"], 
                    $fila["estado"], 
                    $armaObj,               //null u objeto
                    $fila["fuerza"],
                    $fila["armadura"]
                );

                $personajes[] = $guerrero;

            } elseif ($fila["tipoPersonaje"] == "mago"){
                $mago = new Mago(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,           //null u objeto
                    $fila["mana"],
                    $fila["inteligencia"]
                );
                $personajes[] = $mago;
            } else {
                $arquero = new Arquero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,               //null u objeto
                    $fila["precisionPersonaje"],
                    $fila["velocidad"]
                );
                $personajes[] = $arquero;
            }
        }

        return $personajes;
}

//Listar personajes retirados
public function personajesRetirados(){
    $filas = $this->database->select("personajes", "*", ["estado" => "retirado"]);

    //Reutilizo logica de listar personajes
    $personajes = [];
    $armaDatos = new armaDatos($this->database);

        foreach($filas as $fila){
            //verifico si hay arma 
            $armaObj = null;
            if($fila["idArmaEquipada"] != null){
                $armaObj = $armaDatos->buscarArma($fila["idArmaEquipada"]);
            } 

            //Segun tipoPersonaje se crea el objeto Personaje(guerrero/mago/arquero)
            if($fila["tipoPersonaje"] == "guerrero"){

                $guerrero = new Guerrero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"], 
                    $fila["estado"], 
                    $armaObj,               //null u objeto
                    $fila["fuerza"],
                    $fila["armadura"]
                );

                $personajes[] = $guerrero;

            } elseif ($fila["tipoPersonaje"] == "mago"){
                $mago = new Mago(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,           //null u objeto
                    $fila["mana"],
                    $fila["inteligencia"]
                );
                $personajes[] = $mago;
            } else {
                $arquero = new Arquero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,               //null u objeto
                    $fila["precisionPersonaje"],
                    $fila["velocidad"]
                );
                $personajes[] = $arquero;
            }
        }

        return $personajes;
}

//Mostrar el arma equipada por cada personaje
public function armaEquipadaPj(){
    $filas = $this->database->select("personajes", ["nombre", "idArmaEquipada"]);
    $resultado = [];
    $armaDatos = new armaDatos($this->database);
    
    foreach($filas as $fila){
        $arma = null;
        if($fila["idArmaEquipada"] != null){
            $arma = $armaDatos->buscarArma($fila["idArmaEquipada"]);
        }

        $resultado[] = ["personaje" => $fila["nombre"], "arma" => $arma];           
    }
    return $resultado;
}


//Mostrar el ranking de personajes ordenado por cantidad de victorias.
public function rankingPersonajes(){
    $filas = $this->database->select("personajes", "*", ["ORDER" => ["duelosGanados" => "DESC"]]); //Se utiliza el ORDER BY de SQL

    //Reutilizo logica de listar personajes
    $personajes = [];
    $armaDatos = new armaDatos($this->database);

        foreach($filas as $fila){
            //verifico si hay arma 
            $armaObj = null;
            if($fila["idArmaEquipada"] != null){
                $armaObj = $armaDatos->buscarArma($fila["idArmaEquipada"]);
            } 

            //Segun tipoPersonaje se crea el objeto Personaje(guerrero/mago/arquero)
            if($fila["tipoPersonaje"] == "guerrero"){

                $guerrero = new Guerrero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"], 
                    $fila["estado"], 
                    $armaObj,               //null u objeto
                    $fila["fuerza"],
                    $fila["armadura"]
                );

                $personajes[] = $guerrero;

            } elseif ($fila["tipoPersonaje"] == "mago"){
                $mago = new Mago(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,           //null u objeto
                    $fila["mana"],
                    $fila["inteligencia"]
                );
                $personajes[] = $mago;
            } else {
                $arquero = new Arquero(
                    $fila["id"],
                    $fila["nombre"],
                    $fila["nivel"],
                    $fila["puntosVida"],
                    $fila["energia"],
                    $fila["duelosGanados"],
                    $fila["duelosPerdidos"],
                    $fila["estado"],
                    $armaObj,               //null u objeto
                    $fila["precisionPersonaje"],
                    $fila["velocidad"]
                );
                $personajes[] = $arquero;
            }
        }

        return $personajes;
}

//Mostrar el personaje con mayor cantidad de victorias
public function personajeMasVictorias(){
    $ranking = $this->rankingPersonajes(); //Reutilizo metodo anterior 
    $resultado = null;

    //verifico que no este vacio
    if(count($ranking) > 0){
        $resultado = $ranking[0]; //con mas victorias 
    }
    return $resultado; //null o Obj PJ
}

//Mostrar el porcentaje de victorias de cada personaje
public function porcentajeVictoriasPj(){
    $filas = $this->database->select("personajes", ["nombre","duelosGanados", "duelosPerdidos"]);
    $resultado = [];

    foreach($filas as $fila){
        //verifico que haya duelos
        $totalDuelos = ($fila["duelosGanados"] + $fila["duelosPerdidos"]);
        if($totalDuelos <= 0){
            $resultado[] = ["nombrePersonaje" => $fila["nombre"], "porcentajeVictorias" => 0];   
        } else {
            $porcentaje = ( $fila["duelosGanados"] / $totalDuelos ) * 100;
            $resultado[] = ["nombrePersonaje" => $fila["nombre"], "porcentajeVictorias" => $porcentaje];
        }
    }
    return $resultado;
}

}

















