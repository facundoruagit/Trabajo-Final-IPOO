<?php

include_once "personaje.php";

class Guerrero extends Personaje {
    private $fuerza;
    private $armadura;

    
    public function __construct($idPersonaje, $nombre, $nivel, $puntosVida, $energia, $duelosGanados, $duelosPerdidos, $estado, $armaEquipada,$fuerza, $armadura){
        parent::__construct($idPersonaje, $nombre, $nivel, $puntosVida, $energia, $duelosGanados, $duelosPerdidos, $estado, $armaEquipada);
        $this->fuerza = $fuerza;
        $this->armadura = $armadura;
    }

    public function getFuerza(){
        return $this->fuerza;
    }
    public function getArmadura(){
        return $this->armadura;
    }
    public function setFuerza($fuerza){
        $this->fuerza = $fuerza;
    }
    public function setArmadura($armadura){
        $this->armadura = $armadura;
    }

    public function __toString(){
        $cadena = parent::__toString();
        $cadena .= "--ATRIBUTOS DE GUERRERO-- \nFuerza: " . $this->fuerza . "\n" . 
                "Armadura: " .$this->armadura . "\n";
        return $cadena;
    }

    //calcularPoderBase()
    public function calcularPoderBase(){
        $nivel = $this->getNivel();
        $poderBase = $nivel * 15;
        return $poderBase;
    }

    //calcularPoderEspecial()
    public function calcularPoderEspecial(){
        $poderEspecial = $this->fuerza * 2 + $this->armadura;
        return $poderEspecial;
    }
}