<?php
include_once "arma.php";

class armaDatos{            //clase simple (atributos propios)
    private $database;

public function __construct($database){
    $this->database = $database;
}

//convertir listado de arrays a listado de objetos
public function listarArmas(){
 $filas = $this->database->select("armas", "*"); //arreglo con las filas de los datos simulados
 $armas = [];
 
 foreach($filas as $fila){ //repaso de cada fila
    $arma = new Arma ( //creacion de objeto con datos de la base de datos
        $fila["id"],
        $fila["nombre"],
        $fila["tipo"],
        $fila["danioBase"],
        $fila["nivelMinimo"],
        $fila["estado"]
    );
    $armas[]= $arma; //Se agrega a la coleccion
 }
return $armas; //retorno arreglo de objetos
}

//Buscamos dentro de la base un arma con un Id dado por parametro
public function buscarArma($id){
    $fila = $this->database->select("armas", "*", ["id" => $id]); //consulta por id 
    $resultado = null;

    if($fila != null){ //si no esta vacio
        
        $arma = new Arma(
            $fila[0]["id"],
            $fila[0]["nombre"],
            $fila[0]["tipo"],
            $fila[0]["danioBase"],
            $fila[0]["nivelMinimo"],
            $fila[0]["estado"]
            );

        $resultado = $arma; //se asigna a resultado pero no haria falta
    }
    
    return $resultado; //devuelvo objeto o null
}

//Insertamos un arma teniendo en cuenta el parametro (objeto) a la base de datos
public function insertarArma(Arma $arma){

    $this->database->insert("armas", [  //Nota: no se ingresa el ID porque ya en la base de datos se le asigna uno que se autoincrementa por si mismo (AUTO_INCREMENT)
        "nombre" => $arma->getNombreArma(),
        "tipo" => $arma->getTipoArma(),
        "danioBase" => $arma->getDanioBase(),
        "nivelMinimo" => $arma->getNivelMinimo(), 
        "estado" =>$arma->getEstadoArma()
    ]);
}

//Se trata de modificar los atributos de un arma en la base de datos a partir del objeto recibido por parametro
public function modificarArma(Arma $arma){

//update: tabla, modificacion, condicion    
$this->database->update("armas", 
//las modificaciones
["nombre" => $arma->getNombreArma(),
"tipo" => $arma->getTipoArma(),
"danioBase" => $arma->getDanioBase(),
"nivelMinimo" => $arma->getNivelMinimo(),
"estado" => $arma->getEstadoArma()], 
//la condicion
["id" => $arma->getIdArma()]); //si no existe el ID no se modifica nada de la BD

}

//Se elimina un arma de la base de datos teniendo en cuenta su id (mas sencillo)
public function eliminarArma($id){  
//delete: tabla, condicion
$this->database->delete("armas", ["id" => $id]);
}


/*----------------------------------------------------------------------------------------------------------------------------*/

//Listar armas disponibles
public function armasDisponibles(){
$filas = $this->database->select("armas", "*", ["estado" => "disponible"]);

//Reutilizo logica de listar armas
$armas = [];
 
 foreach($filas as $fila){ //repaso de cada fila
    $arma = new Arma ( //creacion de objeto con datos de la base de datos
        $fila["id"],
        $fila["nombre"],
        $fila["tipo"],
        $fila["danioBase"],
        $fila["nivelMinimo"],
        $fila["estado"]
    );
    $armas[]= $arma; //Se agrega a la coleccion
 }
return $armas;
}

}