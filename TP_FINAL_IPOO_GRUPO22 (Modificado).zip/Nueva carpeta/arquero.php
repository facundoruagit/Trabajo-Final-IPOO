<?php
include_once "personaje.php";

class Arquero extends Personaje{
    private $precisionPersonaje;
    private $velocidad; 

   
    public function __construct($idPersonaje, $nombre, $nivel, $puntosVida, $energia, $duelosGanados, $duelosPerdidos, $estado, $armaEquipada, $precisionPersonaje, $velocidad){
        parent::__construct($idPersonaje, $nombre, $nivel, $puntosVida, $energia, $duelosGanados, $duelosPerdidos, $estado, $armaEquipada);
        $this->precisionPersonaje = $precisionPersonaje;
        $this->velocidad = $velocidad; 
    }

    public function getPrecisionPersonaje(){
        return $this->precisionPersonaje;
    }
    public function getVelocidad(){
        return $this->velocidad;
    }
    public function setPrecision($precisionPersonaje){
        $this->precisionPersonaje = $precisionPersonaje;
    }
    public function setVelocidad($velocidad){
        $this->velocidad = $velocidad;
    }

    public function __toString(){
        $cadena = parent::__toString();
        $cadena .= "--ATRIBUTOS DE ARQUERO-- \nPresicion: " . $this->precisionPersonaje . "\n" . 
                  "Velocidad: " . $this->velocidad . "\n";
        return $cadena;
    }

    //calcularPoderBase()
    public function calcularPoderBase(){
        $nivel = $this->getNivel();
        $poderBase = $nivel * 12 + $this->precisionPersonaje;
        return $poderBase;
    }

    //calcularPoderEspecial()
    public function calcularPoderEspecial(){
        $poderEspecial = $this->precisionPersonaje * 2 + $this->velocidad;
        return $poderEspecial;
    }


}