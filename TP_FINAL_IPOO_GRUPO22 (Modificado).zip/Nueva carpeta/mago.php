<?php
include_once "personaje.php";

class Mago extends Personaje {
    private $mana;
    private $inteligencia;

    public function __construct($idPersonaje, $nombre, $nivel, $puntosVida, $energia, $duelosGanados, $duelosPerdidos, $estado, $armaEquipada, $mana, $inteligencia){
        parent::__construct($idPersonaje, $nombre, $nivel, $puntosVida, $energia, $duelosGanados, $duelosPerdidos, $estado, $armaEquipada);
        $this->mana = $mana;
        $this->inteligencia = $inteligencia;
    }

    public function getMana(){
        return $this->mana;
    }
    public function getInteligencia(){
        return $this->inteligencia;
    }
    public function setMana($mana){
        $this->mana = $mana;
    }
    public function setInteligencia($inteligencia){
        $this->inteligencia = $inteligencia;
    }

    public function __toString(){
      $cadena = parent::__toString();  
      $cadena .= "--ATRIBUTOS DE MAGO-- \nMana: " . $this->mana . "\n" .
                "Inteligencia: " . $this->inteligencia . "\n";
      return $cadena; 
    }

    //calcularPoderBase()
    public function calcularPoderBase(){
        $nivel = $this->getNivel();
        $poderBase = $nivel * 10 + $this->mana;
        return $poderBase;
    }

    //calcularPoderEspecial()
    public function calcularPoderEspecial(){
        $poderEspecial = $this->mana + $this->inteligencia * 3;
        return $poderEspecial;
    }
}