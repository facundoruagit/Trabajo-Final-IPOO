<?php
include_once "duelo.php";
include_once "personajeDatos.php";
include_once "arenaDatos.php";
use Medoo\Medoo;

class DueloDatos {      //clase utiliza a objetos
    private $database;

    public function __construct($database){
        $this->database = $database;
    }

//Listado completo
public function listarDuelos(){
    $filas = $this->database->select("duelos", "*");
    $duelos = [];

    //reutilizo Clases de Datos
    $pjDatos = new PersonajeDatos($this->database);
    $arenaDatos = new ArenaDatos($this->database);

    foreach($filas as $fila){

        //busco por ID y retorno Objetos
        $Pj1 = $pjDatos->buscarPersonaje($fila["idPersonaje1"]);
        $Pj2 = $pjDatos->buscarPersonaje($fila["idPersonaje2"]);
        $Arena = $arenaDatos->buscarArena($fila["idArena"]);

        //si hay ganador en duelos busco por ID y retorno Objeto
        $ganadorDuelo = null;
        if($fila["idGanador"] != null){
            $ganadorDuelo = $pjDatos->buscarPersonaje($fila["idGanador"]);
        }

        //creo objeto
        $duelo = new Duelo($fila["id"], $Pj1, $Pj2, $Arena, $fila["fecha"], $fila["estado"], $ganadorDuelo); 
        $duelos[] = $duelo;
    }
    //retorno arrays de objetos
    return $duelos;
}

//Búsqueda por ID
public function buscarDuelo($id){
    $fila = $this->database->select("duelos", "*",["id" => $id]);
    $resultado = null;

    if($fila != null){
        //reutilizo Clases de Datos
        $pjDatos = new PersonajeDatos($this->database);
        $arenaDatos = new ArenaDatos($this->database);

        //paso de Id a Objetos
        $pj1 = $pjDatos->buscarPersonaje($fila[0]["idPersonaje1"]);
        $pj2 = $pjDatos->buscarPersonaje($fila[0]["idPersonaje2"]);
        $arena = $arenaDatos->buscarArena($fila[0]["idArena"]);

        //verifico ganador del duelo
        $ganadorDuelo = null;
        if($fila[0]["idGanador"] != null){
            $ganadorDuelo = $pjDatos->buscarPersonaje($fila[0]["idGanador"]);
        }

        //creo y devuelvo objeto
        $duelo = new Duelo($fila[0]["id"], $pj1, $pj2, $arena, $fila[0]["fecha"], $fila[0]["estado"], $ganadorDuelo);
        $resultado = $duelo;
    } 
    
    return $resultado; //null o objeto
}

//Insertar(alta)
public function insertarDuelo(Duelo $duelo){
    //verifico que haya un ganador
    if($duelo->getGanadorDuelo() != null){
        $idGanador = $duelo->getGanadorDuelo()->getIdPersonaje();
    } else {
        $idGanador = null;
    }

    //no se inserta ID se genera automaticamente en Base de datos
    //no se insertan poderPersonaje1 ni poderPersonaje2 ni danioAplicado porque mi clase Duelo no contempla esos atributos
    $this->database->insert("duelos", [
        "idPersonaje1" => $duelo->getPersonaje1()->getIdPersonaje(),
        "idPersonaje2" => $duelo->getPersonaje2()->getIdPersonaje(),
        "idArena" => $duelo->getArenaDuelo()->getIdArena(),
        "fecha" => $duelo->getFechaDuelo(),
        "estado" => $duelo->getEstadoDuelo(),
        "idGanador" => $idGanador 
    ]);
}

//Modificar
public function modificarDuelo(Duelo $duelo){
    //verifico que haya un ganador
    if($duelo->getGanadorDuelo() != null){
        $idGanador = $duelo->getGanadorDuelo()->getIdPersonaje();
    } else {
        $idGanador = null;
    }
    //modifico segun ID
    $this->database->update("duelos", [
        "idPersonaje1" => $duelo->getPersonaje1()->getIdPersonaje(),
        "idPersonaje2" => $duelo->getPersonaje2()->getIdPersonaje(),
        "idArena" => $duelo->getArenaDuelo()->getIdArena(),
        "fecha" => $duelo->getFechaDuelo(),
        "estado" => $duelo->getEstadoDuelo(),
        "idGanador" => $idGanador 
    ],["id" => $duelo->getIdDuelo()]);

}

//Eliminar (Baja)
public function eliminarDuelo($id){
    $this->database->delete("duelos", ["id" => $id]);
}

/*--------------------------------------------------------------------------------------------------------*/

//Mostrar todos los duelos realizados
public function duelosRealizados(){
    $filas = $this->database->select("duelos", "*", ["estado" => "realizado"]);

    //reutilizo logica de listar duelos
    $duelos = [];

    //reutilizo Clases de Datos
    $pjDatos = new PersonajeDatos($this->database);
    $arenaDatos = new ArenaDatos($this->database);

    foreach($filas as $fila){

        //busco por ID y retorno Objetos
        $Pj1 = $pjDatos->buscarPersonaje($fila["idPersonaje1"]);
        $Pj2 = $pjDatos->buscarPersonaje($fila["idPersonaje2"]);
        $Arena = $arenaDatos->buscarArena($fila["idArena"]);

        //si hay ganador en duelos busco por ID y retorno Objeto
        $ganadorDuelo = null;
        if($fila["idGanador"] != null){
            $ganadorDuelo = $pjDatos->buscarPersonaje($fila["idGanador"]);
        }

        //creo objeto
        $duelo = new Duelo($fila["id"], $Pj1, $Pj2, $Arena, $fila["fecha"], $fila["estado"], $ganadorDuelo); 
        $duelos[] = $duelo;
    }
    //retorno arrays de objetos
    return $duelos;
}

//Mostrar todos los duelos pendientes
public function duelosPendientes(){
    $filas = $this->database->select("duelos", "*", ["estado" => "pendiente"]);

    //reutilizo logica de listar duelos
    $duelos = [];

    //reutilizo Clases de Datos
    $pjDatos = new PersonajeDatos($this->database);
    $arenaDatos = new ArenaDatos($this->database);

    foreach($filas as $fila){

        //busco por ID y retorno Objetos
        $Pj1 = $pjDatos->buscarPersonaje($fila["idPersonaje1"]);
        $Pj2 = $pjDatos->buscarPersonaje($fila["idPersonaje2"]);
        $Arena = $arenaDatos->buscarArena($fila["idArena"]);

        //si hay ganador en duelos busco por ID y retorno Objeto
        $ganadorDuelo = null;
        if($fila["idGanador"] != null){
            $ganadorDuelo = $pjDatos->buscarPersonaje($fila["idGanador"]);
        }

        //creo objeto
        $duelo = new Duelo($fila["id"], $Pj1, $Pj2, $Arena, $fila["fecha"], $fila["estado"], $ganadorDuelo); 
        $duelos[] = $duelo;
    }
    //retorno arrays de objetos
    return $duelos;
}

//Mostrar el historial de duelos de un personaje
public function historialDuelosPj($id){
$filas = $this->database->select("duelos", "*", ["OR" => ["idPersonaje1" => $id, "idPersonaje2" => $id]]); //Utilizacion del conector logico "OR"

//reutilizo logica de listar duelos
    $duelos = [];

    //reutilizo Clases de Datos
    $pjDatos = new PersonajeDatos($this->database);
    $arenaDatos = new ArenaDatos($this->database);

    foreach($filas as $fila){

        //busco por ID y retorno Objetos
        $Pj1 = $pjDatos->buscarPersonaje($fila["idPersonaje1"]);
        $Pj2 = $pjDatos->buscarPersonaje($fila["idPersonaje2"]);
        $Arena = $arenaDatos->buscarArena($fila["idArena"]);

        //si hay ganador en duelos busco por ID y retorno Objeto
        $ganadorDuelo = null;
        if($fila["idGanador"] != null){
            $ganadorDuelo = $pjDatos->buscarPersonaje($fila["idGanador"]);
        }

        //creo objeto
        $duelo = new Duelo($fila["id"], $Pj1, $Pj2, $Arena, $fila["fecha"], $fila["estado"], $ganadorDuelo); 
        $duelos[] = $duelo;
    }
    //retorno arrays de objetos
    return $duelos;
}

//Mostrar la arena donde más duelos se realizaron
public function arenaMasDuelos(){
    $filas = $this->database->select("duelos", ["idArena", "cantidad" => Medoo::raw("COUNT(*)")], ["GROUP" => "idArena", "ORDER" => ["cantidad" => "DESC"]]); //COUNT(), GROUP BY, ORDER BY
    $resultado = null;

    //verifico que la consulta no este vacia
    if(count($filas) > 0){
        $arenaDatos = new ArenaDatos($this->database);
        $arena = $arenaDatos->buscarArena($filas[0]["idArena"]);
        $resultado = $arena;
    }

    return $resultado; //null o Obj Arena
}


}