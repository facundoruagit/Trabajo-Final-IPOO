<?php
include_once "personaje.php";
include_once "guerrero.php";
include_once "mago.php";
include_once "arquero.php";

class Arena {
    private $idArena;
    private $nombreArena;
    private $dificultadArena;
    private $capacidadPublico;
    private $climaArena;      //climas: normal, lluvia, tormenta, niebla

    public function __construct($idArena, $nombreArena, $dificultadArena, $capacidadPublico, $climaArena){
        $this->idArena = $idArena;
        $this->nombreArena = $nombreArena;
        $this->dificultadArena = $dificultadArena;
        $this->capacidadPublico = $capacidadPublico;
        $this->climaArena = $climaArena;
    }

    //getters
    public function getIdArena(){
        return $this->idArena;
    }
    public function getNombreArena(){
        return $this->nombreArena;
    }
    public function getDificultadArena(){
        return $this->dificultadArena;
    }
    public function getCapacidadPublico(){
        return $this->capacidadPublico;
    }
    public function getClimaArena(){
        return $this->climaArena;
    }

    //setters
    public function setIdArena($idArena){
        $this->idArena = $idArena;
    }
    public function setNombreArena($nombreArena){
        $this->nombreArena = $nombreArena;
    }
    public function setDificultadArena($dificultadArena){
        $this->dificultadArena = $dificultadArena;
    }
    public function setCapacidadPublico($capacidadPublico){
        $this->capacidadPublico = $capacidadPublico;
    }
    public function setClimaArena($climaArena){
        $this->climaArena = $climaArena;
    }

    //toString
    public function __toString(){
        return "Id Arena: " . $this->idArena . "\n" . 
                "Nombre Arena: " . $this->nombreArena . "\n" . 
                "Dificultad Arena: " . $this->dificultadArena . "\n" . 
                "Capacidad de publico: " . $this->capacidadPublico . "\n" .
                "Clima Arena: " . $this->climaArena . "\n";
    }

    //calcularModificadorArena()
    public function calcularModificadorArena(Personaje $personaje){
        $modificadorArena = 0;
        $clima = $this->climaArena;

        if($clima == "normal"){             //caso igual para todos, solo se explicita
                $modificadorArena = 0;
            
        } elseif ($clima == "lluvia"){

            if($personaje instanceof Guerrero){
                $modificadorArena = 0;
            } elseif ($personaje instanceof Mago){
                $modificadorArena = +5;
            } elseif ($personaje instanceof Arquero){
                $modificadorArena = -10;
            }
        } elseif ($clima == "tormenta"){

            if($personaje instanceof Guerrero){
                $modificadorArena = -5;
            } elseif ($personaje instanceof Mago){
                $modificadorArena = +15;
            } elseif ($personaje instanceof Arquero){
                $modificadorArena = -5;
            }
        } elseif ($clima == "niebla"){

            if($personaje instanceof Guerrero){
                $modificadorArena = +5;
            } elseif ($personaje instanceof Mago){
                $modificadorArena = 0;
            } elseif ($personaje instanceof Arquero){
                $modificadorArena = -15;
            }
        }

        return $modificadorArena;
    }

}