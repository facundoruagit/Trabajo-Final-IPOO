<?php

class Arma {
    private $idArma;
    private $nombreArma;
    private $tipoArma;
    private $danioBase;
    private $nivelMinimo;
    private $estadoArma; //estados: disponible, equipada y rota

    public function __construct($idArma, $nombreArma, $tipoArma, $danioBase, $nivelMinimo, $estadoArma){
        $this->idArma = $idArma;
        $this->nombreArma = $nombreArma;
        $this->tipoArma = $tipoArma;
        $this->danioBase= $danioBase;
        $this->nivelMinimo = $nivelMinimo;
        $this->estadoArma = $estadoArma;
    }

    //getters
    public function getIdArma(){
        return $this->idArma;
    }
    public function getNombreArma(){
        return $this->nombreArma;
    }
    public function getTipoArma(){
        return $this->tipoArma;
    }
    public function getDanioBase(){
        return $this->danioBase;
    }
    public function getNivelMinimo(){
        return $this->nivelMinimo;
    }
    public function getEstadoArma(){
        return $this->estadoArma;
    }

    //setters
    public function setIdArma($idArma){
        $this->idArma = $idArma;
    }
    public function setNombreArma ($nombreArma){
        $this->nombreArma = $nombreArma;
    }
    public function setTipoArma($tipoArma){
        $this->tipoArma = $tipoArma;
    }
    public function setDanioBase($danioBase){
        $this->danioBase = $danioBase;
    }
    public function setNivelMinimo($nivelMinimo){
        $this->nivelMinimo = $nivelMinimo;
    }
    public function setEstadoArma($estadoArma){
        $this->estadoArma = $estadoArma;
    }

    //toString
    public function __toString(){
        return "Id arma: " . $this->idArma . "\n" . 
                "Nombre Arma: " . $this->nombreArma . "\n" . 
                "Tipo Arma: " . $this->tipoArma . "\n" . 
                "Daño base: " . $this->danioBase . "\n" . 
                "Nivel Minimo: " . $this->nivelMinimo . "\n" . 
                "Estado arma: " . $this->estadoArma . "\n";
    }

    //calcularDanio() 
    public function calcularDanio(){
        $danioBase = $this->danioBase;
        return $danioBase;
    }

    //puedeSerEquipadaPor(Personaje $personaje)
    public function puedeSerEquipadaPor(Personaje $personaje){ 
        $resultado = false;
        $estado = $this->estadoArma;
        $nivelMinimo = $this->nivelMinimo;

        if($estado == "rota" || $estado == "equipada"){
            $resultado = false;
        } elseif ($personaje->getArmaEquipada() == null && $estado == "disponible" && $personaje->getNivel() >= $nivelMinimo){
            $resultado = true;
        }
        return $resultado;
    }


}