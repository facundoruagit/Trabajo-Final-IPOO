<?php
include_once "arma.php";
//include_once "arena.php"; //si ejecuto duelos llamar nuevamente, para la persistencia falla por el momento con el SELECT(*)


abstract class Personaje {
    private $idPersonaje;
    private $nombre;
    private $nivel;
    private $puntosVida;
    private $energia;
    private $duelosGanados;
    private $duelosPerdidos;
    private $estado;        //valores: disponible, lesionado o retirado
    private $armaEquipada;  //objeto arma

    public function __construct($idPersonaje, $nombre, $nivel, $puntosVida, $energia, $duelosGanados, $duelosPerdidos, $estado, $armaEquipada){
        $this->idPersonaje = $idPersonaje;
        $this->nombre = $nombre;
        $this->nivel = $nivel;
        $this->puntosVida = $puntosVida;
        $this->energia = $energia;
        $this->duelosGanados = $duelosGanados;
        $this->duelosPerdidos = $duelosPerdidos;
        $this->estado = $estado;
        $this->armaEquipada = $armaEquipada;
    }

    //getters
    public function getIdPersonaje(){
        return $this->idPersonaje;
    }
    public function getNombre(){
        return $this->nombre;
    }
    public function getNivel(){
        return $this->nivel;
    }
    public function getPuntosVida(){
        return $this->puntosVida;
    }
    public function getEnergia(){
        return $this->energia;
    }
    public function getDuelosGanados(){
        return $this->duelosGanados;
    }
    public function getDuelosPerdidos(){
        return $this->duelosPerdidos;
    }
    public function getEstado(){
        return $this->estado;
    }
    public function getArmaEquipada(){
        return $this->armaEquipada;
    }

    //setters
    public function setIdPersonaje($idPersonaje){
        $this->idPersonaje = $idPersonaje;
    }
    public function setNombre($nombre){
        $this->nombre = $nombre;
    }
    public function setNivel($nivel){
        $this->nivel = $nivel;
    }
    public function setPuntosVida($puntosVida){
        $this->puntosVida = $puntosVida;
    }
    public function setEnergia($energia){
        $this->energia = $energia;
    }
    public function setDuelosGanados($duelosGanados){
        $this->duelosGanados = $duelosGanados;
    }
    public function setDuelosPerdidos($duelosPerdidos){
        $this->duelosPerdidos = $duelosPerdidos;
    }
    public function setEstado($estado){
        $this->estado = $estado;
    }
    public function setArmaEquipada($armaEquipada){
        $this->armaEquipada = $armaEquipada;
    }

    //toString
    public function __toString(){
        return "Id: " . $this->idPersonaje . "\n" . 
                "Nombre: " . $this->nombre . "\n" . 
                "Nivel: " . $this->nivel . "\n" . 
                "Puntos de vida: " . $this->puntosVida . "\n" . 
                "Energia: " . $this->energia . "\n" . 
                "Duelos Ganados: " . $this->duelosGanados . "\n" . 
                "Duelos Perdidos: " . $this->duelosPerdidos . "\n" . 
                "Estado: " . $this->estado . "\n" . 
                "\n--Arma Equipada--\n" . $this->armaEquipada . "\n";
    }

    //recibirDanio($cantidad)
    public function recibirDanio($cantidad){ 
        $resultado = false; 
        $vida = $this->puntosVida - $cantidad;

        if($vida > 30) {  //vida mayor de 30%
            $this->puntosVida -= $cantidad;  
            $this->estado = "disponible";
            $resultado = true;  //vivo 
                    
        } elseif ($vida <= 30 && $vida > 0) { //vida mayor a 0 y menor a 30%
            $this->puntosVida -= $cantidad;  
            $this->estado = "lesionado";
            $resultado = true; //lesionado, pero aun vivo
        
        } elseif ($vida <= 0){ //vida menor o igual a 0
            $this->puntosVida = 0;
            $this->estado = "retirado";
            $resultado = false; //muerto

        } 
        return $resultado;
    }

    //recuperarVida($cantidad)
    public function recuperarVida($cantidad){
        $resultado = false;

        if($this->puntosVida <= 0 && $this->estado == "retirado"){       //nadie se cura si esta muerto desde un comienzo
            return $resultado;
        }

        $vida = $this->puntosVida + $cantidad; 
        if($vida >= 100){
            $this->puntosVida = 100;
            $this->estado = "disponible";
            $resultado = true;
        } elseif ($vida < 100 && $vida > 30){
            $this->puntosVida += $cantidad;
            $this->estado = "disponible";
            $resultado = true;
        } elseif($vida <= 30 && $vida > 0){
            $this->puntosVida += $cantidad;
            $this->estado = "lesionado";
            $resultado = true;
        } elseif ($vida <= 0){
            $this->puntosVida = 0;
            $this->estado = "retirado";
            $resultado = false;
        }

        return $resultado;
    }

    //recuperarEnergia($cantidad)
    public function recuperarEnergia($cantidad){
        $resultado = true;

        if($cantidad <= 0){          //no se aceptan numeros negativos ni 0
            $resultado = false;
            return $resultado;
        }

        $energia = $this->energia + $cantidad; //siempre se recupera valores positivos de energia

        if($energia >= 100){
            $this->energia = 100;
        } elseif($energia < 100 && $energia > 0){
            $this->energia += $cantidad;
        }

        return $resultado;
    }

    //puedeDuelar()
    public function puedeDuelar(){
        $resultado = false;

        if($this->estado == "disponible"){
            $resultado = true;
        }
        
        return $resultado;
    }

    //calcularPoderTotal()
    public function calcularPoderTotal(Arena $arena){
    
    $poderBase = $this->calcularPoderBase();

    $poderEspecial = $this->calcularPoderEspecial();

    if ($this->armaEquipada == null){
        $danioArma = 0;
    } else {
        $danioArma = $this->armaEquipada->calcularDanio();
    }
    
    $modificadorArena = $arena->calcularModificadorArena($this); //Es decir, el objeto($personaje == $this) que llame al metodo

    $poderTotal = $poderBase + $poderEspecial + $danioArma + $modificadorArena;

    return $poderTotal;
    }

    //metodos abstractos

    abstract public function calcularPoderBase();

    abstract public function calcularPoderEspecial();


}

