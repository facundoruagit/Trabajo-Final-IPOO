<?php

include_once "personaje.php";
include_once "arena.php";

class Duelo {
    private $idDuelo;
    private $personaje1; //obj
    private $personaje2; //obj
    private $arenaDuelo; //obj
    private $fechaDuelo;
    private $estadoDuelo; //estados: pendiente(por defecto), realizado y cancelado
    private $ganadorDuelo; //null o pj1 o pj2

    public function __construct($idDuelo, $personaje1, $personaje2, $arenaDuelo, $fechaDuelo, $estadoDuelo, $ganadorDuelo){
        $this->idDuelo = $idDuelo;
        $this->personaje1 = $personaje1;
        $this->personaje2 = $personaje2;
        $this->arenaDuelo = $arenaDuelo;
        $this->fechaDuelo = $fechaDuelo;
        $this->estadoDuelo = $estadoDuelo;
        $this->ganadorDuelo = $ganadorDuelo;
    }

    //getters
    public function getIdDuelo (){
        return $this->idDuelo;
    }
    public function getPersonaje1 (){
        return $this->personaje1;
    }
    public function getPersonaje2 (){
        return $this->personaje2;
    }
    public function getArenaDuelo (){
        return $this->arenaDuelo;
    }
    public function getFechaDuelo (){
        return $this->fechaDuelo;
    }
    public function getEstadoDuelo (){
        return $this->estadoDuelo;
    }
    public function getGanadorDuelo (){
        return $this->ganadorDuelo;
    }

    //setters
    public function setIdDuelo ($idDuelo){
        $this->idDuelo = $idDuelo;
    }
    public function setPersonaje1 ($personaje1){
        $this->personaje1 = $personaje1;
    }
    public function setPersonaje2 ($personaje2){
        $this->personaje2 = $personaje2;
    }
    public function setArenaDuelo ($arenaDuelo){
        $this->arenaDuelo = $arenaDuelo;
    }
    public function setFechaDuelo ($fechaDuelo){
        $this->fechaDuelo = $fechaDuelo;
    }
    public function setEstadoDuelo ($estadoDuelo){
        $this->estadoDuelo = $estadoDuelo;
    }
    public function setGanadorDuelo ($ganadorDuelo){
        $this->ganadorDuelo = $ganadorDuelo;
    }

    //toString
    public function __toString(){
        //Verifico que haya ganador
        $ganador = null;
        if($this->ganadorDuelo != null){
            $ganador = $this->ganadorDuelo->getNombre();
        }
        return "Id Duelo: " . $this->idDuelo . "\n\n" . 
                "== PERSONAJE 1 ==\n" . $this->personaje1 . "\n" . 
                "== PERSONAJE 2 ==\n" . $this->personaje2 . "\n" .
                "== Arena Duelo ==\n" . $this->arenaDuelo . "\n" . 
                "Fecha Duelo: " . $this->fechaDuelo . "\n" . 
                "Estado Duelo: " . $this->estadoDuelo . "\n" . 
                "Ganador Duelo: " . $ganador . "\n"; 
        
    }

    //puedeRealizarse()
    public function puedeRealizarse(){
        $resultado = true;

        $pj1 = $this->personaje1;
        $pj2 = $this->personaje2;


        if($pj1 == null || $pj2 == null){ //Si no existen, no se realiza
            $resultado = false;

        } elseif($pj1->getIdPersonaje() == $pj2->getIdPersonaje()){ //Si son el mismo Pj, no se realiza
            $resultado = false;

        } elseif(!$pj1->puedeDuelar() || !$pj2->puedeDuelar()){ //Reutilizo funcion de Pj
            $resultado = false;
        }

        return $resultado;
    }

    //realizarDuelo()
    public function realizarDuelo(){
    $duelo = $this->puedeRealizarse();
    $resultado = 0;                     //0: empate, 1: pj1, 2:pj2

    if($duelo){
        $poderPj1 = $this->personaje1->calcularPoderTotal($this->arenaDuelo);
        $poderPj2 = $this->personaje2->calcularPoderTotal($this->arenaDuelo);

        if($poderPj1 > $poderPj2){
            $resultado = 1;
            $this->ganadorDuelo = $this->personaje1;
            $this->estadoDuelo = "realizado";

            //Ganador
            //aumenta el nivel a +1
            $nivel1 = $this->personaje1->getNivel();
            $nivelActual1 = $nivel1 + 1;
            $this->personaje1->setNivel($nivelActual1);

            //recupera +5 de energia
            $this->personaje1->recuperarEnergia(5);

            //Incrementa en +1 sus duelos ganados
            $duelosGanados1 = $this->personaje1->getDuelosGanados();
            $duelosGanadosActuales1 = $duelosGanados1 + 1;
            $this->personaje1->setDuelosGanados($duelosGanadosActuales1);

            //Perdedor
            //Recibe daño
            $cantidad = $poderPj1 - $poderPj2;
            $this->personaje2->recibirDanio($cantidad);

            //Incrementa en +1 sus duelos perdidos
            $duelosPerdidos2 = $this->personaje2->getDuelosPerdidos();
            $duelosPerdidosActuales2 = $duelosPerdidos2 + 1;
            $this->personaje2->setDuelosPerdidos($duelosPerdidosActuales2);
            
            //Pierde -5 de energia
            $energia = $this->personaje2->getEnergia();
            $energiaActual = $energia - 5;
            if($energiaActual <= 0){            //la energia no queda en valor negativo
                $energiaActual = 0;   
            }
            $this->personaje2->setEnergia($energiaActual);
            
            

        } elseif ($poderPj2 > $poderPj1){
            $resultado = 2;
            $this->ganadorDuelo = $this->personaje2;
            $this->estadoDuelo = "realizado";

            //Ganador
            //aumenta el nivel a +1
            $nivel2 = $this->personaje2->getNivel();
            $nivelActual2 = $nivel2 + 1;
            $this->personaje2->setNivel($nivelActual2);

            //recupera +5 de energia
            $this->personaje2->recuperarEnergia(5);

            //Incrementa en +1 sus duelos ganados
            $duelosGanados2 = $this->personaje2->getDuelosGanados();
            $duelosGanadosActuales2 = $duelosGanados2 + 1;
            $this->personaje2->setDuelosGanados($duelosGanadosActuales2);

            //Perdedor
            //Recibe daño
            $cantidad = $poderPj2 - $poderPj1;
            $this->personaje1->recibirDanio($cantidad);

            //Incrementa en +1 sus duelos perdidos
            $duelosPerdidos1 = $this->personaje1->getDuelosPerdidos();
            $duelosPerdidosActuales1 = $duelosPerdidos1 + 1;
            $this->personaje1->setDuelosPerdidos($duelosPerdidosActuales1);
            
            //Pierde -5 de energia
            $energia = $this->personaje1->getEnergia();
            $energiaActual = $energia - 5;
            if($energiaActual <= 0){            //la energia no queda en valor negativo
                $energiaActual = 0;
            } 
            $this->personaje1->setEnergia($energiaActual);
            

            
        } else {
            $resultado = 0;
            $this->estadoDuelo = "realizado"; //sin ganador
        }

    } else {
        $this->estadoDuelo = "cancelado";
    }
    return $resultado;
    }

    //obtenerGanador()
    public function obtenerGanador(){
        $resultado = null;
        if($this->ganadorDuelo != null){
            $resultado = $this->ganadorDuelo;
        }
        return $resultado;
    }

}



