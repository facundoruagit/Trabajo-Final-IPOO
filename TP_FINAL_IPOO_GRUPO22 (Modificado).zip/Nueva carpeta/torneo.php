<?php

include_once "personaje.php";
include_once "arena.php";

class torneo {
    private $arregloPersonajes; //coleccion
    private $arregloArmas;  //coleccion
    private $arregloArenas; //coleccion
    private $arregloDuelos; //coleccion

    public function __construct($arregloPersonajes, $arregloArmas, $arregloArenas, $arregloDuelos){
        $this->arregloPersonajes = $arregloPersonajes;
        $this->arregloArmas = $arregloArmas;
        $this->arregloArenas = $arregloArenas;
        $this->arregloDuelos = $arregloDuelos;
    }

    //getters 
    public function getArregloPersonajes (){
        return $this->arregloPersonajes;
    }
    public function getArregloArmas (){
        return $this->arregloArmas;
    }
    public function getArregloArenas (){
        return $this->arregloArenas;
    }
    public function getArregloDuelos (){
        return $this->arregloDuelos;
    }

    //setters 
    public function setArregloPersonajes($arregloPersonajes){
        $this->arregloPersonajes = $arregloPersonajes;
    }
    public function setArregloArmas($arregloArmas){
        $this->arregloArmas = $arregloArmas;
    }
    public function setArregloArenas($arregloArenas){
        $this->arregloArenas = $arregloArenas;
    }
    public function setArregloDuelos($arregloDuelos){
        $this->arregloDuelos = $arregloDuelos;
    }

    //toString
    public function __toString(){
        return "Coleccion de Personajes: \n" . $this->arregloPersonajes . "\n" . 
                "Coleccion de Armas: \n" . $this->arregloArmas . "\n" . 
                "Coleccion de Arenas: \n" . $this->arregloArenas . "\n" . 
                "Coleccion de Duelos: \n" . $this->arregloDuelos . "\n";
    }

    //agregarPersonaje()
    public function agregarPersonaje(Personaje $pj){
        $resultado = false; //true si se pudo agregar el pj
        $existe = false; //false si no existe 

        foreach($this->arregloPersonajes as $personaje){
            if($personaje->getIdPersonaje() == $pj->getIdPersonaje()){
                $existe = true; //existe en el arreglo
            }
        }

        if (!$existe){ //si no existe en el arreglo se agrega
            $resultado = true;
            $this->arregloPersonajes[] = $pj;
        }
        return $resultado;
    }

    //agregarArma()
    public function agregarArma(Arma $arma){
        $resultado = false;
        $existe = false;

        foreach($this->arregloArmas as $arm){
            if($arm->getIdArma() == $arma->getIdArma()){
                $existe = true;
            }
        }

        if(!$existe){ //si no existe arma en el arreglo se agrega
            $resultado = true;
            $this->arregloArmas[] = $arma;
        }
        return $resultado;
    }

    //agregarArena()
    public function agregarArena(Arena $arena){
        $resultado = false;
        $existe = false;

        foreach($this->arregloArenas as $arenaX){
            if($arenaX->getIdArena() == $arena->getIdArena()){
                $existe = true;
            }
        }

        if(!$existe){ //si no existe dentro del arreglo se agrega
            $resultado = true;
            $this->arregloArenas[] = $arena;
        }
        return $resultado;
    }

    //equiparArma()
    public function equiparArma ($idArma, $idPersonaje){
        $resultado = false;
        $arma = null;
        $pj = null;

        //busco arma por ID en el arreglo
        foreach($this->arregloArmas as $arm){
            if($arm->getIdArma() == $idArma){
                $arma = $arm;
            }
        }

        //busco personaje por ID en el arreglo
        foreach($this->arregloPersonajes as $personaje){
            if($personaje->getIdPersonaje() == $idPersonaje){
                $pj = $personaje;
            }
        }

        //Si arma y pj no estan en null, se modifica el estado del arma y el arma equipada del personaje
        if($arma != null && $pj != null) {
            if($arma->puedeSerEquipadaPor($pj)){

                $arma->setEstadoArma("equipada");   //pasa a estar equipada
                $pj->setArmaEquipada($arma);        //personaje pasa a tener un arma equipada
                $resultado = true;
            }
        }

        return $resultado;
    }

    //registrarDuelo()
    public function registrarDuelo($idArena, $idDuelo, $fechaDuelo, $idPersonaje1, $idPersonaje2){
        $resultado = false;
        $pj1 = null;
        $pj2 = null;
        $arena = null;
        $duelo = null;

        //busco dentro de arreglos (pj1, pj2, arena y duelo)
        foreach($this->arregloPersonajes as $personajeX){
            if($personajeX->getIdPersonaje() == $idPersonaje1){
                $pj1 = $personajeX; 
            }
            if($personajeX->getIdPersonaje() == $idPersonaje2){
                $pj2 = $personajeX;
            }
        }

        foreach ($this->arregloArenas as $arenaX){
            if($arenaX->getIdArena() == $idArena){
                $arena = $arenaX;
            }
        }

        foreach($this->arregloDuelos as $dueloX){
            if($dueloX->getIdDuelo() == $idDuelo){
                $duelo = $dueloX;
            }
        }

        //verifico que no exista duelo repetido
        if($duelo == null && $arena != null && $pj1 != null && $pj2 != null){
            //creo duelo
            $duelo = new Duelo($idDuelo, $pj1, $pj2, $arena, $fechaDuelo, "pendiente", null);

            //si puede realizarse (reutilizo funcion) agrego a la coleccion
            if($duelo->puedeRealizarse()){
                $resultado = true;
                $this->arregloDuelos[] = $duelo;
            }

        }
        return $resultado;
    }

    //realizarDuelo()
    public function realizarDuelo($idDuelo){
    $resultado = null;
    $duelo = null;

    //corrobo que exista duelo
    foreach($this->arregloDuelos as $dueloX){
        if($dueloX->getIdDuelo() == $idDuelo){
            $duelo = $dueloX;
        }
    } 
    
    //ejecuto mediante metodo realizarDuelo()
    if($duelo != null){
        $resultado = $duelo->realizarDuelo();
    }
    return $resultado; //retorna el ganador/empate/no hay duelo: (0, 1, 2) o null
    }

    //listarPersonajes() 
    public function listarPersonajes(){
        $cadena = "";
        $indicePj = 1;

        //Si no hay personajes en el arreglo
        if(count($this->arregloPersonajes) == 0){
            $cadena = "No hay personajes registrados.";
        }
        
        //recorre y retorna cadena de Pjs
        foreach($this->arregloPersonajes as $personaje){
            $cadena .= "Personaje n°" . $indicePj . ": \n" . $personaje; //Nota: de aqui en adelante se aprovecha el __toString() de la clase correspondiente
            $indicePj++;
        }
        return $cadena;
    }

    //listarArmas()
    public function listarArmas(){
        $cadena = "";
        $indiceArma = 1;

        //Si no hay armas en el arreglo
        if(count($this->arregloArmas) == 0){
            $cadena = "No hay armas registradas.";
        }

        //recorre y retorna cadena de armas
        foreach($this->arregloArmas as $arma){
            $cadena.= "Arma n°" . $indiceArma . ": \n" . $arma;
            $indiceArma++;
        }
        return $cadena;
    }

    //listarArenas()
    public function listarArenas(){
        $cadena = "";
        $indiceArena = 1;

        //si no hay arenas en el arreglo
        if(count($this->arregloArenas) == 0){
            $cadena = "No hay arenas registradas.";
        }

        //recorre y retorna cadena de arenas
        foreach($this->arregloArenas as $arena){
            $cadena.= "Arena n°" . $indiceArena . ": \n" . $arena;
            $indiceArena++;
        }
        return $cadena;
    }

    //listarDuelos()
    public function listarDuelos(){
        $cadena = ""; 
        $indiceDuelo = 1;

        //si no hay duelos en el arreglo 
        if(count($this->arregloDuelos) == 0){
            $cadena = "No hay duelos registrados.";
        }
        foreach($this->arregloDuelos as $duelo){
            $cadena .= "Duelo n°" . $indiceDuelo . ": \n" . $duelo;
            $indiceDuelo++;
        }
        return $cadena;
    }

    //rankingPersonajes()
    public function rankingPersonajes(){
        $cadena = "";
        $indiceRanking = 1;
        $personajes = $this->getArregloPersonajes();

        //verifico si el arreglo esta vacio
        if(count($personajes) == 0){
            $cadena = "No hay personajes registrados.";
        }

        //usort() y funcion utilizada como criterio
        usort ($personajes, function ($a, $b) {
            return $b->getDuelosGanados() <=> $a->getDuelosGanados(); //operador nave espacial: B < A = -1; B == A = 0; B > A = 1; (Orden Descendente o Mayor/Menor)
        });                                                             

        //recorro arreglo ordenado segun duelos ganados y devuelvo cadena
        foreach ($personajes as $pj){
            $cadena .= "Personaje n°" . $indiceRanking . ": \n" . $pj;
            $indiceRanking++;
        }
        return $cadena;
    }
}