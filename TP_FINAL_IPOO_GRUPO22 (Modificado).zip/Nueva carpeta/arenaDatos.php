<?php 
include_once "arena.php";

class ArenaDatos{           //clase simple (atributos propios)
    private $database;
    
    public function __construct($database){
        $this->database = $database;
    }

    //Listado completo de objetos
    public function listarArenas(){
        $filas = $this->database->select("arenas", "*");
        $arenas = [];

        foreach($filas as $fila){
            $arena = new Arena(
                $fila["id"],
                $fila["nombre"],
                $fila["dificultad"],
                $fila["capacidadPublico"],
                $fila["clima"]
            );

            $arenas[] = $arena;
        }
        return $arenas; //array de objetos arena
    }

    //Búsqueda por ID
    public function buscarArena($id){
        $fila = $this->database->select("arenas", "*", ["id" => $id]);
        $resultado = null;

        if($fila != null){
            $arena = new Arena(
                $fila[0]["id"],
                $fila[0]["nombre"],
                $fila[0]["dificultad"],
                $fila[0]["capacidadPublico"],
                $fila[0]["clima"]
            );

            $resultado = $arena;
        }
        return $resultado; //null o objeto
    }

    //alta
    public function insertarArena(Arena $arena){
        //no se inserta ID, lo crea la base de datos
        $this->database->insert("arenas", [
            "nombre" => $arena->getNombreArena(), 
            "dificultad" => $arena->getDificultadArena(), 
            "capacidadPublico" => $arena->getCapacidadPublico(), 
            "clima" => $arena->getClimaArena()
        ]);
    }

    //modificacion
    public function modificarArena(Arena $arena){
            $this->database->update("arenas", 
            //las modificaciones
            [
            "nombre" => $arena->getNombreArena(), 
            "dificultad" => $arena->getDificultadArena(), 
            "capacidadPublico" => $arena->getCapacidadPublico(), 
            "clima" => $arena->getClimaArena()
            ],
            //la condicion
            ["id" => $arena->getIdArena()]);
    }

    //baja
    public function eliminarArena($id){
        $this->database->delete("arenas", ["id" => $id]);
    }


}