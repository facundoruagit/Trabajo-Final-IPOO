<?php
//clases que interactuan con los datos de mi BD
include_once "armaDatos.php";
include_once "personajeDatos.php";
include_once "arenaDatos.php";
include_once "dueloDatos.php";

//coneccion con MEDOO (PHP a BASE DE DATOS)
require 'Medoo.php'; //Es como el include
use Medoo\Medoo; //Utilizacion de la clase Medoo

$database = new Medoo([
	// Obligatorio.
	'type' => 'mysql', //Motor de base de datos: PostgreSQL, MySQL, Microsoft SQL Server, etcetera. 
	'host' => 'localhost', //servidor local (Mi PC)
	'database' => 'torneo_duelos', //Nombre de Base de datos creada
	'username' => 'root',
	'password' => ''
]);


//=================== PROGRAMA PRINCIPAL ===================

//Inicializo mis clasesDatos
$armaDatos = new armaDatos($database);
$arenaDatos = new ArenaDatos($database);
$personajeDatos = new PersonajeDatos($database);
$dueloDatos = new DueloDatos($database);

//funciones prestablecidas de php utilizadas 

//trim(): Elimina espacios en blanco y otros caracteres invisibles (como tabuladores y saltos de línea) tanto al principio como al final de una cadena de texto. 
//fgets(STDIN): Captura lo que escribe el usuario desde su teclado.
//ucfirst(): Convierte solo el primer carácter de una cadena de texto a mayúscula.
//strtolower(): Convierte todos los caracteres alfabéticos de una cadena de texto a minúsculas. 
//isset(): Sirve para comprobar si una variable existe y si su valor no es nulo (null).
//count(): Cuenta el número de elementos de un arreglo (array).
//date(): Permite formatear la fecha y hora actuales en una cadena legible

//validar cadenas de texto vacias
function validarTexto(){
    $texto = trim(fgets(STDIN));

    while($texto == ""){
        echo "Valor invalido.\n"; 
		echo "Ingrese nuevamente: ";
        $texto = (string) trim(fgets(STDIN));
    }
	//normalizacion de texto
	$textoNormalizado = ucfirst(strtolower($texto));  //Normalizacion: Primera en mayuscula y el resto en minuscula

    return $textoNormalizado;
}

//funcion de validacion de rangos
function validarNum($min, $max){
	$num = (int) trim(fgets(STDIN));
	
	while ($num > $max || $num < $min){
		echo "valor invalido!\n";
		echo "Ingrese nuevamente (" . $min . "/" . $max ."): ";
		$num = (int) trim(fgets(STDIN));
	}
	return $num;
}

$opcion = -1;

while($opcion != 0){
	echo "\n============ Los Juegos del Hambre ============\n";
	echo "1.Registrar Personajes.\n";
	echo "2.Registrar Armas.\n";
	echo "3.Registrar Arenas.\n";
	echo "4.Equipar Armas.\n";
	echo "5.Registrar Duelos.\n";
	echo "6.Ejecutar Duelos Pendientes.\n";
	echo "7.Recuperar Personajes Lesionados.\n";
	echo "8.Consultar Rankings.\n";
	echo "9.Consultar Historial de Personajes.\n";
    echo "10.Consultas Generales.\n";
    echo "11.Gestion de Registros.\n";
	echo "0. Salir.\n";

	echo "\nIngrese una opcion: ";
	$opcion = trim(fgets(STDIN));

	switch($opcion){
		case 1:
			echo "Ingrese nombre de su personaje: ";
			$nombre = validarTexto();

			echo "Ingrese nivel de su personaje (1/100): ";
			$nivel = validarNum(1, 100);		

			echo "Ingrese puntos de vida de su personaje (1/100): ";
			$vida = validarNum(1, 100);	

			echo "Ingrese energia de su personaje (1/100): ";
			$energia = validarNum(1, 100);	

			//estado del personaje
			if($vida > 30){
				$estado = "disponible";
			} else {
				$estado = "lesionado";
			}

			echo "Seleccione tipo de personaje (Guerrero/Mago/Arquero): ";
			$tipoPj = (string) trim(fgets(STDIN));

			if (strtolower($tipoPj) == "guerrero"){

				echo "Ingrese armadura de su personaje (1/100): ";
				$armadura = validarNum(1, 100);

				echo "Ingrese fuerza de su personaje (1/100): ";
				$fuerza = validarNum(1, 100);

				$guerrero = new Guerrero("", $nombre, $nivel, $vida, $energia, 0, 0, $estado, null, $fuerza, $armadura);
				$personajeDatos->insertarPersonaje($guerrero);

                echo "\n========== PERSONAJE REGISTRADO ==========\n";
                echo $guerrero;
                echo "==========================================\n";

			} elseif (strtolower($tipoPj) == "mago"){

				echo "Ingrese mana de su personaje (1/100): ";
				$mana = validarNum(1, 100);

				echo "Ingrese inteligencia de su personaje (1/100): ";
				$inteligencia = validarNum(1, 100);

				$mago = new Mago("", $nombre, $nivel, $vida, $energia, 0, 0, $estado, null, $mana, $inteligencia);
				$personajeDatos->insertarPersonaje($mago);

                echo "\n========== PERSONAJE REGISTRADO ==========\n";
                echo $mago;
                echo "==========================================\n";

			} elseif (strtolower($tipoPj) == "arquero"){

				echo "Ingrese precision de su personaje (1/100): ";
				$precision = validarNum(1, 100);

				echo "Ingrese velocidad de su personaje (1/100): ";
				$velocidad = validarNum(1, 100);

				$arquero = new Arquero("", $nombre, $nivel, $vida, $energia, 0, 0, $estado, null, $precision, $velocidad);
				$personajeDatos->insertarPersonaje($arquero);
				
                echo "\n========== PERSONAJE REGISTRADO ==========\n";
                echo $arquero;
                echo "==========================================\n";

			} else {
				echo "Tipo de personaje invalido!\n";
			}
			break; 

		case 2:
			echo "Ingrese nombre del arma: ";
            $nombre = validarTexto();

            echo "Ingrese tipo de arma (Ej.: Espada): ";
            $tipoArma = validarTexto();

            echo "Ingrese daño base (1/100): ";
            $danio = validarNum(1, 100);	

            echo "Ingrese nivel minimo (1/100): ";
            $nivelMin = validarNum(1,100);	

            echo "Ingrese estado del arma (disponible/rota): ";
            $estadoArma = strtolower(trim(fgets(STDIN)));

            while($estadoArma != "disponible" && $estadoArma != "rota"){
                echo "Estado invalido!\n";
                echo "Ingrese nuevamente (disponible/rota): ";
                $estadoArma = strtolower(trim(fgets(STDIN)));
            }

            $arma = new Arma("", $nombre, $tipoArma, $danio, $nivelMin, $estadoArma);
            $armaDatos->insertarArma($arma);

            echo "\n========== ARMA REGISTRADA ==========\n";
            echo $arma;
            echo "=====================================\n";

            break;

		case 3:
			echo "Ingrese nombre arena: ";
			$nombre = validarTexto();

			echo "Ingrese dificultad arena (1/10): ";
			$dificultad = validarNum(1,10);	

			echo "Ingrese la capacidad del publico (1/5000): ";
			$capacidad = validarNum(1,5000);	

			echo "Ingrese clima de la arena (normal/lluvia/tormenta/niebla): ";
			$climaArena = strtolower((string) trim(fgets(STDIN)));

			if ($climaArena != "normal" && $climaArena != "lluvia" && $climaArena != "tormenta" && $climaArena != "niebla"){
				echo "clima invalido!\n";
				break;

			} else {
				$arena = new Arena("", $nombre, $dificultad, $capacidad, $climaArena);
				$arenaDatos->insertarArena($arena);
				
                echo "\n========== ARENA REGISTRADA ==========\n";
                echo $arena;
                echo "======================================\n";
			}
			break;

		case 4:
			//Verifico personajes disponibles
			$personajes = $personajeDatos->personajesDisponibles();
			if(count($personajes) > 0){

				//Muestro personajes disponibles
				echo "\n== PERSONAJES DISPONIBLES == \n";
				$id = 1;
				foreach ($personajes as $pj){
					echo "\nOPCIÓN " . $id. ": \n". $pj . "\n\n";
					$id++;
				}
				echo "Seleccione un personaje: \n";
				$rta1 = (int) trim(fgets(STDIN)); 
				$rta1--; //indice real

			} else {
				echo "No se encontraron personajes disponibles.\n";
				break;
			}

			//Verifico armas disponibles
			$armas = $armaDatos->armasDisponibles();
			if (count($armas) > 0){

				//Muestro armas disponibles
				echo "\n== ARMAS DISPONIBLES ==\n";
				$id = 1;
				foreach($armas as $arma){
				echo "\nOPCIÓN " . $id. ": \n". $arma . "\n\n";
				$id++;
				}
				echo "Seleccione un arma: \n";
				$rta2 = (int) trim(fgets(STDIN));
				$rta2--; //indice real

			} else {
				echo "No se encontraron armas disponibles.\n";
				break;
			}

			//Traigo Personaje y Arma seleccionada 
			if(isset($personajes[$rta1]) && isset($armas[$rta2])) { //compruebo existencia del objeto dentro del arreglo
				$personaje = $personajes[$rta1];
				$arma = $armas[$rta2];

				if($arma->puedeSerEquipadaPor($personaje)){
					//Inserto con setters
					$personaje->setArmaEquipada($arma);
					$arma->setEstadoArma("equipada");

					//modifico en la Base de datos
					$personajeDatos->modificarPersonaje($personaje);
					$armaDatos->modificarArma($arma);

					echo "\n========== ARMA EQUIPADA ==========\n";
                    echo "\n--- PERSONAJE ACTUALIZADO ---\n";
                    echo $personaje;
                    echo "\n--- ARMA ACTUALIZADA ---\n";
                    echo $arma;
                    echo "==================================\n";

				} else {
					echo "El arma no puede ser equipada!\n";
				}

			} else {
				echo "Opcion invalida!\n";
				echo "No existe el personaje o el arma seleccionados.\n";
			}
			break;

		case 5:
			$personajes = $personajeDatos->personajesDisponibles();

			//Verifico si hay personajes disponibles (2 minimo)
			if(count($personajes) >= 2){
				//Muestro personajes disponibles
				echo "\n== PERSONAJES DISPONIBLES == \n";

				$id = 1;
				foreach ($personajes as $pj){
					echo "\nOPCIÓN n°" . $id. ": \n". $pj . "\n\n";
					$id++;
				}
				echo "Seleccione personaje n°1: \n";
				$rta1 = (int) trim(fgets(STDIN)); 
				$rta1--; //indice real

				echo "Seleccione personaje n°2: \n";
				$rta2 = (int) trim(fgets(STDIN));
				$rta2--; //indice real

			} else {
				echo "No se encontraron personajes disponibles.\n";
				break;
			}
			 
			$arenas = $arenaDatos->listarArenas();

			//verifico si hay arenas disponibles
			if(count($arenas) > 0){
				//Muestro arenas disponibles
				echo "\n== ARENAS DISPONIBLES ==\n";

				$id = 1;
				foreach($arenas as $arena){
					echo "\nOPCIÓN " . $id. ": \n". $arena . "\n\n";
					$id++;
				}
				echo "Seleccione arena: \n";
				$rta3 = (int) trim(fgets(STDIN)); 
				$rta3--; //indice real

			} else {
				echo "No se encontraron arenas disponibles.\n";
				break;
			}

			//Asigno fecha actual
			$fecha = date("Y-m-d"); 	//YYYY-MM-DD
			echo "Fecha de duelo asignada: " . $fecha . "\n";

			//Convalido datos, traigo y creo objetos
			if(isset($personajes[$rta1]) && isset($personajes[$rta2]) && isset($arenas[$rta3])){ //si existen dentro de sus arreglos
				$personaje1 = $personajes[$rta1];
				$personaje2 = $personajes[$rta2];
				$arena = $arenas[$rta3];

				$duelo = new Duelo("", $personaje1, $personaje2, $arena, $fecha, "pendiente", null);

				if($duelo->puedeRealizarse()){
					$dueloDatos->insertarDuelo($duelo);
					
                    echo "\n========== DUELO REGISTRADO ==========\n";
                    echo $duelo;
                    echo "======================================\n";
				} else {
					echo "El duelo no puede realizarse.\n";
				}

			} else {
				echo "Opcion invalida!\n";
				echo "No existe alguno de los personajes o arena seleccionados.\n";
			}
			break;

		case 6:
            $duelosPendientes = $dueloDatos->duelosPendientes();

            //Verifico que haya duelos pendientes
            if(count($duelosPendientes) > 0){
                echo "\n== DUELOS PENDIENTES ==\n\n";

                $id = 1;
                foreach($duelosPendientes as $duelo){
                    echo "\n=== Duelo n°" . $id . " ===\n". $duelo . "\n\n";
                    $id++;
                }

                echo "Seleccione un duelo para ejecutarlo: \n";
                $rta1 = (int) trim(fgets(STDIN));
                $rta1--; //indice real

            } else {
                echo "No se encontraron duelos pendientes.\n";
                break;
            }
            
            //Verifico si existe el duelo dentro del arreglo
            if(isset($duelosPendientes[$rta1])){
                $duelo = $duelosPendientes[$rta1];

                //Verifico que pueda realizarse
                if($duelo->puedeRealizarse()){

                    //Ejecuto Duelo
                    $duelo->realizarDuelo();

                    //Modifico en mi Base de Datos
                    $personajeDatos->modificarPersonaje($duelo->getPersonaje1());
                    $personajeDatos->modificarPersonaje($duelo->getPersonaje2());
                    $dueloDatos->modificarDuelo($duelo);

                    //Obtengo personajes actualizados
                    $personaje1 = $duelo->getPersonaje1();
                    $personaje2 = $duelo->getPersonaje2();
                    $ganador = $duelo->obtenerGanador();

                    echo "\n========== DUELO FINALIZADO ==========\n";
                    echo "Id Duelo: " . $duelo->getIdDuelo() . "\n";
                    echo "Estado del duelo: " . $duelo->getEstadoDuelo() . "\n";

                    if($ganador != null){
                        echo "Ganador: " . $ganador->getNombre() . "\n";
                    } else {
                        echo "Resultado: Empate. No hubo ganador.\n";
                    }

                    echo "\n--- PERSONAJE 1 ---\n";
                    echo "Nombre: " . $personaje1->getNombre() . "\n";
                    echo "Vida: " . $personaje1->getPuntosVida() . "\n";
                    echo "Energia: " . $personaje1->getEnergia() . "\n";
                    echo "Estado: " . $personaje1->getEstado() . "\n";
                    echo "Duelos ganados: " . $personaje1->getDuelosGanados() . "\n";
                    echo "Duelos perdidos: " . $personaje1->getDuelosPerdidos() . "\n";

                    echo "\n--- PERSONAJE 2 ---\n";
                    echo "Nombre: " . $personaje2->getNombre() . "\n";
                    echo "Vida: " . $personaje2->getPuntosVida() . "\n";
                    echo "Energia: " . $personaje2->getEnergia() . "\n";
                    echo "Estado: " . $personaje2->getEstado() . "\n";
                    echo "Duelos ganados: " . $personaje2->getDuelosGanados() . "\n";
                    echo "Duelos perdidos: " . $personaje2->getDuelosPerdidos() . "\n";

                    echo "======================================\n";

                } else {
                    echo "El duelo no puede realizarse.\n";
                }

            } else {
                echo "Opcion invalida!\n";
                echo "No existe duelo.\n";
            }
            break;

		case 7:
			$pjsLesionados = $personajeDatos->personajesLesionados();

			//Verifico array vacio
			if(count($pjsLesionados) > 0){
				//Muestro personajes lesionados
				echo "\n== PERSONAJES LESIONADOS ==\n";

				$id = 1;
				foreach($pjsLesionados as $pj){
					echo "\nOPCIÓN n°" . $id. ": \n". $pj . "\n\n";
					$id++;
				} 
				echo "Seleccione un personaje para su recuperacion: ";
				$rta1 = (int) trim(fgets(STDIN));
				$rta1--; //indice real

				echo "Cuanto puntos de vida desea recuperar? (1/100): ";
				$cantidadVida = validarNum(1,100);

				echo "Cuanto puntos de energia desea recuperar? (1/100):";
				$cantidadEnergia = validarNum(1,100);

				//Verifico existencia del elemento en el array
				if(isset($pjsLesionados[$rta1])){
					//Recupero vida y energia
					$personaje = $pjsLesionados[$rta1];
					$personaje->recuperarVida($cantidadVida);
					$personaje->recuperarEnergia($cantidadEnergia);

					//Modifico en la base de datos
					$personajeDatos->modificarPersonaje($personaje);
					
                    echo "\n========== PERSONAJE RECUPERADO ==========\n";
                    echo $personaje;
                    echo "==========================================\n";

				} else {
					echo "Opcion invalida!\n";
					echo "No existe personaje.\n";
					break;
				}
				
			} else {
				echo "No hay personajes lesionados.\n";
			}
			break;

		case 8:
			$rankingPjs = $personajeDatos->rankingPersonajes();

			//verifico si hay elementos en el array
			if(count($rankingPjs) > 0){
				//Muestro ranking
				echo "\n=== Ranking de Personajes ===\n";

				$id = 1;
				foreach($rankingPjs as $pj){
					echo $id . "°. " . $pj->getNombre() . " - Victorias: " . $pj->getDuelosGanados() . "\n";
					$id++;
				}
			} else {
				echo "No hay personajes en el ranking.\n";
			}
			break;

		case 9:
			$personajes = $personajeDatos->listarPersonajes();

			//Verifico que haya elementos en el array
			if(count($personajes) > 0){
				//Muestro personajes disponibles
				echo "\n== PERSONAJES ==\n";

				$id = 1;
				foreach ($personajes as $pj){
					echo "\n== PERSONAJE n°" . $id. " ==\n". $pj . "\n\n";
					$id++;
				}
				echo "Seleccione un personaje para visualizar su historial: ";
				$rta1 = (int) trim(fgets(STDIN));
				$rta1--; //indice real

			} else {
				echo "No hay personajes disponibles.\n";
				break;
			}
			
			//Verifico existencia en el array
			if(isset($personajes[$rta1])){
				$personaje = $personajes[$rta1];
				
				//Accedo a su historial por id
				$historial = $dueloDatos->historialDuelosPj($personaje->getIdPersonaje());
				if(count($historial) > 0){
					echo "\n== HISTORIAL DE DUELOS ==\n";

					$id = 1;
					foreach($historial as $duelo){
						echo "\nDUELO n°" . $id . ": \n" . $duelo . "\n\n";
						$id++; 
					}

				} else {
					echo "No hay duelos registrados.\n";
				}
				
			} else {
				echo "Opcion incorrecta!\n";
				echo "El personaje seleccionado no existe.\n";
			}
			break;

		
        case 10:
            $subConsulta = -1;

            while($subConsulta != 0){
                echo "\n========== CONSULTAS GENERALES ==========\n";
                echo "1. Listar todos los personajes.\n";
                echo "2. Listar personajes disponibles para duelar.\n";
                echo "3. Listar personajes lesionados.\n";
                echo "4. Listar personajes retirados.\n";
                echo "5. Listar armas disponibles.\n";
                echo "6. Mostrar arma equipada por cada personaje.\n";
                echo "7. Mostrar duelos realizados.\n";
                echo "8. Mostrar duelos pendientes.\n";
                echo "9. Mostrar personaje con más victorias.\n";
                echo "10. Mostrar porcentaje de victorias por personaje.\n";
                echo "11. Mostrar arena donde más duelos se realizaron.\n";
                echo "0. Volver al menú principal.\n";

                echo "\nIngrese una opción: ";
                $subConsulta = trim(fgets(STDIN));

                switch($subConsulta){

                    case 1:
                        $personajes = $personajeDatos->listarPersonajes();
                        echo "\n========== TODOS LOS PERSONAJES ==========\n";
                        if(count($personajes) > 0){
                            foreach($personajes as $pj){
                                echo $pj . "\n";
                            }
                        } else {
                            echo "No hay personajes registrados.\n";
                        }
                        break;

                    case 2:
                        $personajes = $personajeDatos->personajesDisponibles();
                        echo "\n========== PERSONAJES DISPONIBLES ==========\n";
                        if(count($personajes) > 0){
                            foreach($personajes as $pj){
                                echo $pj . "\n";
                            }
                        } else {
                            echo "No hay personajes disponibles.\n";
                        }
                        break;

                    case 3:
                        $personajes = $personajeDatos->personajesLesionados();
                        echo "\n========== PERSONAJES LESIONADOS ==========\n";
                        if(count($personajes) > 0){
                            foreach($personajes as $pj){
                                echo $pj . "\n";
                            }
                        } else {
                            echo "No hay personajes lesionados.\n";
                        }
                        break;

                    case 4:
                        $personajes = $personajeDatos->personajesRetirados();
                        echo "\n========== PERSONAJES RETIRADOS ==========\n";
                        if(count($personajes) > 0){
                            foreach($personajes as $pj){
                                echo $pj . "\n";
                            }
                        } else {
                            echo "No hay personajes retirados.\n";
                        }
                        break;

                    case 5:
                        $armas = $armaDatos->armasDisponibles();
                        echo "\n========== ARMAS DISPONIBLES ==========\n";
                        if(count($armas) > 0){
                            foreach($armas as $arma){
                                echo $arma . "\n";
                            }
                        } else {
                            echo "No hay armas disponibles.\n";
                        }
                        break;

                    case 6:
                        $lista = $personajeDatos->armaEquipadaPj();
                        echo "\n========== ARMA EQUIPADA POR PERSONAJE ==========\n";
                        if(count($lista) > 0){
                            foreach($lista as $fila){
                                echo "Personaje: " . $fila["personaje"] . "\n";
                                if($fila["arma"] != null){
                                    echo "Arma equipada:\n" . $fila["arma"] . "\n";
                                } else {
                                    echo "Arma equipada: Ninguna\n";
                                }
                                echo "--------------------------------------\n";
                            }
                        } else {
                            echo "No hay personajes registrados.\n";
                        }
                        break;

                    case 7:
                        $duelos = $dueloDatos->duelosRealizados();
                        echo "\n========== DUELOS REALIZADOS ==========\n";
                        if(count($duelos) > 0){
                            foreach($duelos as $duelo){
                                echo $duelo . "\n";
                            }
                        } else {
                            echo "No hay duelos realizados.\n";
                        }
                        break;

                    case 8:
                        $duelos = $dueloDatos->duelosPendientes();
                        echo "\n========== DUELOS PENDIENTES ==========\n";
                        if(count($duelos) > 0){
                            foreach($duelos as $duelo){
                                echo $duelo . "\n";
                            }
                        } else {
                            echo "No hay duelos pendientes.\n";
                        }
                        break;

                    case 9:
                        $personaje = $personajeDatos->personajeMasVictorias();
                        echo "\n========== PERSONAJE CON MAS VICTORIAS ==========\n";
                        if($personaje != null){
                            echo $personaje;
                        } else {
                            echo "No hay personajes registrados.\n";
                        }
                        break;

                    case 10:
                        $porcentajes = $personajeDatos->porcentajeVictoriasPj();
                        echo "\n========== PORCENTAJE DE VICTORIAS ==========\n";
                        if(count($porcentajes) > 0){
                            foreach($porcentajes as $fila){
                                echo "Personaje: " . $fila["nombrePersonaje"] . "\n";
                                echo "Porcentaje de victorias: " . round($fila["porcentajeVictorias"], 2) . "%\n";
                                echo "--------------------------------------\n";
                            }
                        } else {
                            echo "No hay personajes registrados.\n";
                        }
                        break;

                    case 11:
                        $arena = $dueloDatos->arenaMasDuelos();
                        echo "\n========== ARENA CON MAS DUELOS ==========\n";
                        if($arena != null){
                            echo $arena;
                        } else {
                            echo "No hay duelos registrados.\n";
                        }
                        break;

                    case 0:
                        echo "Volviendo al menu principal...\n";
                        break;

                    default:
                        echo "Opcion invalida.\n";
                        break;
                }
            }

            break;

        case 11:

            $subConsulta = -1;

            while ($subConsulta != 0){
                echo "\n========== GESTION DE REGISTROS ==========\n";
                echo "1. Gestionar Personajes.\n";
                echo "2. Gestionar Armas.\n";
                echo "3. Gestionar Arenas.\n";
                echo "4. Gestionar Duelos.\n";
                echo "0. Volver al menu principal.\n";

                echo "\nIngrese una opcion: ";
                $subConsulta = trim(fgets(STDIN));

                switch($subConsulta){

                    case 1:
                        echo "\n--- GESTION PERSONAJES ---\n";
                        echo "1. Listar personajes.\n";
                        echo "2. Buscar personaje por ID.\n";
                        echo "3. Modificar personaje.\n";
                        echo "4. Eliminar personaje.\n";
                        echo "Ingrese opcion: ";
                        $op = trim(fgets(STDIN));

                        if($op == 1){
                            $personajes = $personajeDatos->listarPersonajes();
                            foreach($personajes as $pj){
                                echo "\n" . $pj . "\n";
                            }

                        } elseif($op == 2){
                            echo "Ingrese ID: ";
                            $id = (int) trim(fgets(STDIN));
                            $pj = $personajeDatos->buscarPersonaje($id);

                            if($pj != null){
                                echo "\n========== PERSONAJE ENCONTRADO ==========\n";
                                echo $pj;
                            } else {
                                echo "No existe personaje con ese ID.\n";
                            }

                        } elseif($op == 3){
                            echo "Ingrese ID del personaje a modificar: ";
                            $id = (int) trim(fgets(STDIN));
                            $pj = $personajeDatos->buscarPersonaje($id);

                            if($pj != null){
                                echo "\nPersonaje actual:\n" . $pj;

                                echo "Nuevo nombre: ";
                                $nombre = validarTexto();

                                echo "Nuevo nivel (1/100): ";
                                $nivel = validarNum(1,100);

                                echo "Nueva vida (1/100): ";
                                $vida = validarNum(1,100);

                                echo "Nueva energia (1/100): ";
                                $energia = validarNum(1,100);

                                $pj->setNombre($nombre);
                                $pj->setNivel($nivel);
                                $pj->setPuntosVida($vida);
                                $pj->setEnergia($energia);

                                if($vida > 30){
                                    $pj->setEstado("disponible");
                                } else {
                                    $pj->setEstado("lesionado");
                                }

                                $personajeDatos->modificarPersonaje($pj);

                                echo "\n========== PERSONAJE MODIFICADO ==========\n";
                                echo $pj;
                            } else {
                                echo "No existe personaje con ese ID.\n";
                            }

                        } elseif($op == 4){
                            echo "Ingrese ID del personaje a eliminar: ";
                            $id = (int) trim(fgets(STDIN));
                            $pj = $personajeDatos->buscarPersonaje($id);

                            if($pj != null){
                                echo "\nPersonaje eliminado:\n" . $pj;
                                $personajeDatos->eliminarPersonaje($id);
                            } else {
                                echo "No existe personaje con ese ID.\n";
                            }
                        }
                        break;

                    case 2:
                        echo "\n--- GESTION ARMAS ---\n";
                        echo "1. Listar armas.\n";
                        echo "2. Buscar arma por ID.\n";
                        echo "3. Modificar arma.\n";
                        echo "4. Eliminar arma.\n";
                        echo "Ingrese opcion: ";
                        $op = trim(fgets(STDIN));

                        if($op == 1){
                            $armas = $armaDatos->listarArmas();
                            foreach($armas as $arma){
                                echo "\n" . $arma . "\n";
                            }

                        } elseif($op == 2){
                            echo "Ingrese ID: ";
                            $id = (int) trim(fgets(STDIN));
                            $arma = $armaDatos->buscarArma($id);

                            if($arma != null){
                                echo "\n========== ARMA ENCONTRADA ==========\n";
                                echo $arma;
                            } else {
                                echo "No existe arma con ese ID.\n";
                            }

                        } elseif($op == 3){
                            echo "Ingrese ID del arma a modificar: ";
                            $id = (int) trim(fgets(STDIN));
                            $arma = $armaDatos->buscarArma($id);

                            if($arma != null){
                                echo "\nArma actual:\n" . $arma;

                                echo "Nuevo nombre: ";
                                $nombre = validarTexto();

                                echo "Nuevo tipo: ";
                                $tipo = validarTexto();

                                echo "Nuevo daño base (1/100): ";
                                $danio = validarNum(1,100);

                                echo "Nuevo nivel minimo (1/100): ";
                                $nivelMin = validarNum(1,100);

                                echo "Nuevo estado (disponible/equipada/rota): ";
                                $estado = strtolower(trim(fgets(STDIN)));

                                while($estado != "disponible" && $estado != "equipada" && $estado != "rota"){
                                    echo "Estado invalido. Ingrese nuevamente: ";
                                    $estado = strtolower(trim(fgets(STDIN)));
                                }

                                $arma->setNombreArma($nombre);
                                $arma->setTipoArma($tipo);
                                $arma->setDanioBase($danio);
                                $arma->setNivelMinimo($nivelMin);
                                $arma->setEstadoArma($estado);

                                $armaDatos->modificarArma($arma);

                                echo "\n========== ARMA MODIFICADA ==========\n";
                                echo $arma;
                            } else {
                                echo "No existe arma con ese ID.\n";
                            }

                        } elseif($op == 4){
                            echo "Ingrese ID del arma a eliminar: ";
                            $id = (int) trim(fgets(STDIN));
                            $arma = $armaDatos->buscarArma($id);

                            if($arma != null){
                                echo "\nArma eliminada:\n" . $arma;
                                $armaDatos->eliminarArma($id);
                            } else {
                                echo "No existe arma con ese ID.\n";
                            }
                        }
                        break;

                    case 3:
                        echo "\n--- GESTION ARENAS ---\n";
                        echo "1. Listar arenas.\n";
                        echo "2. Buscar arena por ID.\n";
                        echo "3. Modificar arena.\n";
                        echo "4. Eliminar arena.\n";
                        echo "Ingrese opcion: ";
                        $op = trim(fgets(STDIN));

                        if($op == 1){
                            $arenas = $arenaDatos->listarArenas();
                            foreach($arenas as $arena){
                                echo "\n" . $arena . "\n";
                            }

                        } elseif($op == 2){
                            echo "Ingrese ID: ";
                            $id = (int) trim(fgets(STDIN));
                            $arena = $arenaDatos->buscarArena($id);

                            if($arena != null){
                                echo "\n========== ARENA ENCONTRADA ==========\n";
                                echo $arena;
                            } else {
                                echo "No existe arena con ese ID.\n";
                            }

                        } elseif($op == 3){
                            echo "Ingrese ID de la arena a modificar: ";
                            $id = (int) trim(fgets(STDIN));
                            $arena = $arenaDatos->buscarArena($id);

                            if($arena != null){
                                echo "\nArena actual:\n" . $arena;

                                echo "Nuevo nombre: ";
                                $nombre = validarTexto();

                                echo "Nueva dificultad (1/10): ";
                                $dificultad = validarNum(1,10);

                                echo "Nueva capacidad publico (1/5000): ";
                                $capacidad = validarNum(1,5000);

                                echo "Nuevo clima (normal/lluvia/tormenta/niebla): ";
                                $clima = strtolower(trim(fgets(STDIN)));

                                while($clima != "normal" && $clima != "lluvia" && $clima != "tormenta" && $clima != "niebla"){
                                    echo "Clima invalido. Ingrese nuevamente: ";
                                    $clima = strtolower(trim(fgets(STDIN)));
                                }

                                $arena->setNombreArena($nombre);
                                $arena->setDificultadArena($dificultad);
                                $arena->setCapacidadPublico($capacidad);
                                $arena->setClimaArena($clima);

                                $arenaDatos->modificarArena($arena);

                                echo "\n========== ARENA MODIFICADA ==========\n";
                                echo $arena;
                            } else {
                                echo "No existe arena con ese ID.\n";
                            }

                        } elseif($op == 4){
                            echo "Ingrese ID de la arena a eliminar: ";
                            $id = (int) trim(fgets(STDIN));
                            $arena = $arenaDatos->buscarArena($id);

                            if($arena != null){
                                echo "\nArena eliminada:\n" . $arena;
                                $arenaDatos->eliminarArena($id);
                            } else {
                                echo "No existe arena con ese ID.\n";
                            }
                        }
                        break;

                    case 4:
                        echo "\n--- GESTION DUELOS ---\n";
                        echo "1. Listar duelos.\n";
                        echo "2. Buscar duelo por ID.\n";
                        echo "3. Modificar estado del duelo.\n";
                        echo "4. Eliminar duelo.\n";
                        echo "Ingrese opcion: ";
                        $op = trim(fgets(STDIN));

                        if($op == 1){
                            $duelos = $dueloDatos->listarDuelos();
                            foreach($duelos as $duelo){
                                echo "\n" . $duelo . "\n";
                            }

                        } elseif($op == 2){
                            echo "Ingrese ID: ";
                            $id = (int) trim(fgets(STDIN));
                            $duelo = $dueloDatos->buscarDuelo($id);

                            if($duelo != null){
                                echo "\n========== DUELO ENCONTRADO ==========\n";
                                echo $duelo;
                            } else {
                                echo "No existe duelo con ese ID.\n";
                            }

                        } elseif($op == 3){
                            echo "Ingrese ID del duelo a modificar: ";
                            $id = (int) trim(fgets(STDIN));
                            $duelo = $dueloDatos->buscarDuelo($id);

                            if($duelo != null){
                                echo "\nDuelo actual:\n" . $duelo;

                                echo "Nuevo estado (pendiente/realizado/cancelado): ";
                                $estado = strtolower(trim(fgets(STDIN)));

                                while($estado != "pendiente" && $estado != "realizado" && $estado != "cancelado"){
                                    echo "Estado invalido. Ingrese nuevamente: ";
                                    $estado = strtolower(trim(fgets(STDIN)));
                                }

                                $duelo->setEstadoDuelo($estado);
                                $dueloDatos->modificarDuelo($duelo);

                                echo "\n========== DUELO MODIFICADO ==========\n";
                                echo $duelo;
                            } else {
                                echo "No existe duelo con ese ID.\n";
                            }

                        } elseif($op == 4){
                            echo "Ingrese ID del duelo a eliminar: ";
                            $id = (int) trim(fgets(STDIN));
                            $duelo = $dueloDatos->buscarDuelo($id);

                            if($duelo != null){
                                echo "\nDuelo eliminado:\n" . $duelo;
                                $dueloDatos->eliminarDuelo($id);
                            } else {
                                echo "No existe duelo con ese ID.\n";
                            }
                        }
                        break;

                    case 0:
                        echo "Volviendo al menu principal...\n";
                        break;

                    default:
                        echo "Opcion invalida.\n";
                        break;
                }
            }
            break;

		case 0:
			echo "\nGracias por participar!\n";
			echo "Saliendo del programa...\n";
			break;

		default:
			echo "Opcion Invalida!\n";
			break;
	}
}








